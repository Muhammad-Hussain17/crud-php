<?php


$host = "localhost";
$dbuser  = "root";
$dbpass = "";
$dbname = "cc";




$conn = new mysqli($host , $dbuser , $dbpass , $dbname) ;



if($conn->connect_error)

{


echo '<script> alert("Database Error"); </script>';


}



?>